#include <stdio.h>
#include <stdlib.h>
void mrarray(int *arr,int size);
int main()
{

    FILE *ofile= NULL;

    ofile=fopen("output.txt","w");

    if(!ofile){printf("error file not found");
    return 1;}
    printf("file accesed\n");

    int num2;
printf("enter a number bigger than 1 if you hate your hard drive!");
scanf("%d",&num2);
        for (double i = 0; i <= num2; i++) {
        for(double j=0; j<=i;j++ ){
        for (double k = 0; k <= j; k++) {
        for(double l=0; l<=k;l++){
        double bignumber=i*j*k*l;
        double biggernumber= bignumber*bignumber;
        for(double p=bignumber;p<biggernumber;p*p){
            double riphdd=p*p;
            fprintf(ofile, "baba boom! %f",riphdd);
            }
            }
            }
    }
    }

    fclose(ofile);
    return 0;
}

